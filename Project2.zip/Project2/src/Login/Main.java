package Login;

public class Main {
    public static void main(String[] args) {
        Login LoginPanel = new Login();
        LoginPanel.setVisible(true);
        LoginPanel.setLocationRelativeTo(null);
    }
}
