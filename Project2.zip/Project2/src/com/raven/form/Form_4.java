package com.raven.form;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.table.DefaultTableModel;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class Form_4 extends javax.swing.JPanel {
    int userid;
    public void getBalance(int userid) {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        int user_balance = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("SELECT balance FROM digital_wallet WHERE user_id='"+userid+"'");
            ResultSet rs = ps.executeQuery();
            balance.setText("");
            while(rs.next()) {
                user_balance = rs.getInt("balance");
                balance.setText(""+user_balance+"");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    public void listUserID(int userid) {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("SELECT username FROM digital_wallet WHERE NOT user_id='"+userid+"'");
            ResultSet rs = ps.executeQuery();
            user_list.removeAllItems();
            while(rs.next()) {
                user_list.addItem(rs.getString("username"));
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    public void sendMoney(int userid) {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        int receiver_balance = 0;
        int sender_balance = 0;
        
        DateFormat dfor = new SimpleDateFormat("dd/MM/yyyy");
        Calendar obj = Calendar.getInstance();
        String date = dfor.format(obj.getTime());
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            if("".equals(send_money_amount.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Enter an amount!", "Error", JOptionPane.ERROR_MESSAGE);
            } else if("".equals(selected_user.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Select an user!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
            PreparedStatement ps = con.prepareStatement("SELECT balance FROM digital_wallet WHERE username=?");
            ps.setString(1, selected_user.getText());
            ResultSet rs = ps.executeQuery();
            if(rs.next()==true) {
                receiver_balance = rs.getInt("balance");
            }
            int sendMoney = Integer.parseInt(send_money_amount.getText());
            
            ps = con.prepareStatement("UPDATE digital_wallet SET balance=? WHERE username=?");
            ps.setInt(1, (sendMoney + receiver_balance));
            ps.setString(2, selected_user.getText());
            
            int i = ps.executeUpdate();
            if(i==1) {
                selected_user.setText("");
                send_money_amount.setText("");
            }
            
            ps = con.prepareStatement("SELECT balance FROM digital_wallet WHERE user_id='"+userid+"'");
            rs = ps.executeQuery();
            if(rs.next()==true) {
                sender_balance = rs.getInt("balance");
            }
            
            ps = con.prepareStatement("UPDATE digital_wallet SET balance=? WHERE user_id='"+userid+"'");
            ps.setInt(1, (sender_balance - sendMoney));
            
            Statement st = con.createStatement();
            String query = "INSERT INTO transaction_record(user_id, type, date, amount)" + "VALUES('"+userid+"' , 'Send' , '"+date+"', '"+sendMoney+"')";
            st.execute(query);
            
            int j = ps.executeUpdate();
            if(j==1) {
                JOptionPane.showMessageDialog(this, "Record updated successfully!");
                selected_user.setText("");
                send_money_amount.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Record Update Unsuccessful!");
            }
            
        } catch(Exception e) {
                System.out.println("Error: " + e);
        }
    }
    public Form_4(int userid) {
        initComponents();
        this.userid = userid;
        getBalance(userid);
        listUserID(userid);
    }
    public void getUser() {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        String pid = user_list.getSelectedItem().toString();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("SELECT username FROM digital_wallet WHERE username=?");
            ps.setString(1, pid);
            ResultSet rs = ps.executeQuery();
            if(rs.next()==true) {
                selected_user.setText(rs.getString("username")); 
            }
            else {
                JOptionPane.showMessageDialog(this, "No Record Found!");
            }
        } catch(Exception e) {
            System.out.println("Eroor: " + e);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        balance = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        user_list = new javax.swing.JComboBox<>();
        search_user = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        send_money_amount = new javax.swing.JTextField();
        send_money = new javax.swing.JButton();
        selected_user = new javax.swing.JTextField();

        setBackground(new java.awt.Color(242, 242, 242));

        jPanel1.setBackground(new java.awt.Color(242, 242, 242));

        jLabel1.setFont(new java.awt.Font("Roboto Slab", 1, 24)); // NOI18N
        jLabel1.setText("Transfer Money");

        jLabel3.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Current Balance");

        balance.setEditable(false);
        balance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                balanceActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Enter Amount");

        jLabel6.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Select User");

        user_list.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        search_user.setText("Select");
        search_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_userActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Selected User");

        send_money_amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                send_money_amountActionPerformed(evt);
            }
        });

        send_money.setText("Transfer Money");
        send_money.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                send_moneyActionPerformed(evt);
            }
        });

        selected_user.setEditable(false);
        selected_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selected_userActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(279, 279, 279)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(164, 164, 164)
                        .addComponent(send_money, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(user_list, 0, 195, Short.MAX_VALUE)
                                    .addComponent(balance, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
                                    .addComponent(send_money_amount, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
                                    .addComponent(selected_user)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(search_user, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(143, 143, 143)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(369, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(80, 80, 80)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(balance, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(user_list, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(search_user, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(selected_user, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(send_money_amount, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57)
                .addComponent(send_money, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(290, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1095, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 753, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void balanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_balanceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_balanceActionPerformed

    private void search_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_userActionPerformed
        getUser();
    }//GEN-LAST:event_search_userActionPerformed

    private void send_money_amountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_send_money_amountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_send_money_amountActionPerformed

    private void send_moneyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_send_moneyActionPerformed
        sendMoney(userid);
        getBalance(userid);
    }//GEN-LAST:event_send_moneyActionPerformed

    private void selected_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selected_userActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_selected_userActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField balance;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton search_user;
    private javax.swing.JTextField selected_user;
    private javax.swing.JButton send_money;
    private javax.swing.JTextField send_money_amount;
    private javax.swing.JComboBox<String> user_list;
    // End of variables declaration//GEN-END:variables
}
