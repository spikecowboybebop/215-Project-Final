/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.raven.form;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author RAVEN
 */
public class Form_3 extends javax.swing.JPanel {
        int userid;
        public void setLoan(int userid) {
        String id, date, description, amount;
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();
            if("".equals(savings_description.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Description is required!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if("".equals(savings_date.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Date is required!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if("".equals(savings_amount.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Amount is required!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else {
                description = savings_description.getText().trim();
                date = savings_date.getText().trim();
                amount = savings_amount.getText().trim();
                
                String query = "INSERT INTO loan(user_id, date, description, amount)" + "VALUES('"+userid+"' , '"+date+"' , '"+description+"' , '"+amount+"')";
                st.execute(query);
                savings_description.setText("");
                savings_date.setText("");
                savings_amount.setText("");
                showMessageDialog(null, "New account has been created successfully!");
            }
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
        public void listLoanID(int userid) {
            String url = "jdbc:MySQL://localhost/finance_management_system";
            String user = "root";
            String pass = "";
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, pass);
                PreparedStatement ps = con.prepareStatement("SELECT id FROM loan WHERE user_id='"+userid+"'");
                ResultSet rs = ps.executeQuery();
                search_savings.removeAllItems();
                while(rs.next()) {
                    search_savings.addItem(rs.getString(1));
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        public void getLoan() {
            String url = "jdbc:MySQL://localhost/finance_management_system";
            String user = "root";
            String pass = "";
            String pid = search_savings.getSelectedItem().toString();
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, pass);
                PreparedStatement ps = con.prepareStatement("SELECT * FROM loan WHERE id=?");
                ps.setString(1, pid);
                ResultSet rs = ps.executeQuery();
                if(rs.next()==true) {
                    savings_date.setText(rs.getString(3));
                    savings_description.setText(rs.getString(4));
                    savings_amount.setText(rs.getString(5));   
                }
                else {
                    JOptionPane.showMessageDialog(this, "No Record Found!");
                }
            } catch(Exception e) {
                System.out.println("Eroor: " + e);
            }
        }
        public void updateLoan(int userid) {
            String url = "jdbc:MySQL://localhost/finance_management_system";
            String user = "root";
            String pass = "";
            String description = savings_description.getText();
            String date = savings_date.getText();
            String amount = savings_amount.getText();
            String id = search_savings.getSelectedItem().toString();
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, pass);
                PreparedStatement ps = con.prepareStatement("UPDATE loan SET description=?, date=?, amount=? WHERE id=?");
                ps.setString(1, description);
                ps.setString(2, date);
                ps.setString(3, amount);
                ps.setString(4, id);
                int i = ps.executeUpdate();
                if(i==1) {
                    JOptionPane.showMessageDialog(this, "Record updated successfully!");
                    savings_description.setText("");
                    savings_date.setText("");
                    savings_amount.setText("");
                    savings_description.requestFocus();
                    listLoanID(userid);
                } else {
                    JOptionPane.showMessageDialog(this, "Record Update Unsuccessful!");
                }
            } catch(Exception e) {
                System.out.println("Eroor: " + e);
            }
        }
        public void deleteLoan(int userid) {
            String url = "jdbc:MySQL://localhost/finance_management_system";
            String user = "root";
            String pass = "";
            String id = search_savings.getSelectedItem().toString();
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, pass);
                PreparedStatement ps = con.prepareStatement("DELETE FROM loan WHERE id=?");
                ps.setString(1, id);
                int i = ps.executeUpdate();
                if(i==1) {
                    JOptionPane.showMessageDialog(this, "Record Deleted successfully!");
                    savings_description.setText("");
                    savings_date.setText("");
                    savings_amount.setText("");
                    savings_description.requestFocus();
                    listLoanID(userid);
                } else {
                    JOptionPane.showMessageDialog(this, "Record Delete Unsuccessful!");
                }
            } catch(Exception e) {
                System.out.println("Eroor: " + e);
            }
        }
        public void displayRecord(int userid) {
            String url = "jdbc:MySQL://localhost/finance_management_system";
            String user = "root";
            String pass = "";
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, pass);
                PreparedStatement ps = con.prepareStatement("SELECT * FROM loan WHERE user_id='"+userid+"'");
                ResultSet rs = ps.executeQuery();
                ResultSetMetaData rss = rs.getMetaData();
                int a = rss.getColumnCount();

                DefaultTableModel df = (DefaultTableModel)jTable1.getModel();
                df.setRowCount(0);
                while(rs.next()) {
                    Vector data = new Vector();
                    for(int i = 1; i <= a; i++) {
                        data.add(rs.getString("id"));
                        data.add(rs.getString("date"));
                        data.add(rs.getString("description"));
                        data.add(rs.getString("amount"));
                    }
                    df.addRow(data);
                }
            } catch (Exception e) {
                System.out.println("Error: 1" + e);
            }
        }
    public Form_3(int userid) {
        this.userid = userid;
        initComponents();
        listLoanID(userid);
        displayRecord(userid);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        savings_description = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        savings_date = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        savings_amount = new javax.swing.JTextField();
        savings_create = new javax.swing.JButton();
        savings_update = new javax.swing.JButton();
        expense_delete = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        search_savings = new javax.swing.JComboBox<>();
        savings_search = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new com.raven.swing.Table();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        ir = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        ny = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        la = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        mp = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        tp = new javax.swing.JTextField();
        loan_calculate = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Roboto Slab", 1, 24)); // NOI18N
        jLabel1.setText("Manage Loan/Liabilities");

        jLabel3.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Loan Amount Calculator");

        savings_description.setText("Describe your loan");
        savings_description.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savings_descriptionActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Date");

        savings_date.setText("Enter Date");
        savings_date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savings_dateActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Enter Amount");

        savings_amount.setText("Enter Amount");
        savings_amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savings_amountActionPerformed(evt);
            }
        });

        savings_create.setText("Create");
        savings_create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savings_createActionPerformed(evt);
            }
        });

        savings_update.setText("Update");
        savings_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savings_updateActionPerformed(evt);
            }
        });

        expense_delete.setText("Delete");
        expense_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expense_deleteActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Loan ID");

        search_savings.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        savings_search.setText("Search");
        savings_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savings_searchActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Date", "Description", "Amount"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel7.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Description");

        jLabel8.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Interest Rate");

        ir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                irActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Number of Years");

        ny.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nyActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Loan Amount");

        la.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                laActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Monthy Payment");

        mp.setEditable(false);
        mp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mpActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("Total Payment");

        tp.setEditable(false);
        tp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tpActionPerformed(evt);
            }
        });

        loan_calculate.setText("Calculate");
        loan_calculate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loan_calculateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 862, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(savings_create, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(savings_update, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(expense_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(search_savings, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(savings_search, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(mp, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(tp, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(loan_calculate, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(ir, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(ny, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(la, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(63, 63, 63))
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(savings_description, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(savings_date, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(savings_amount, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(204, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(savings_description, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(savings_date, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(savings_amount, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(savings_update, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(expense_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(savings_create, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(search_savings)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(savings_search, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ir, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ny, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(la, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(loan_calculate, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(152, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void savings_descriptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savings_descriptionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_savings_descriptionActionPerformed

    private void savings_dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savings_dateActionPerformed

    }//GEN-LAST:event_savings_dateActionPerformed

    private void savings_amountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savings_amountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_savings_amountActionPerformed

    private void savings_createActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savings_createActionPerformed
        setLoan(userid);
        listLoanID(userid);
        displayRecord(userid);
    }//GEN-LAST:event_savings_createActionPerformed

    private void savings_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savings_updateActionPerformed
        updateLoan(userid);
        listLoanID(userid);
        displayRecord(userid);
    }//GEN-LAST:event_savings_updateActionPerformed

    private void expense_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expense_deleteActionPerformed
        deleteLoan(userid);
        listLoanID(userid);
        displayRecord(userid);
    }//GEN-LAST:event_expense_deleteActionPerformed

    private void savings_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savings_searchActionPerformed
        getLoan();
    }//GEN-LAST:event_savings_searchActionPerformed

    private void irActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_irActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_irActionPerformed

    private void nyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nyActionPerformed

    private void laActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_laActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_laActionPerformed

    private void mpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mpActionPerformed

    private void tpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tpActionPerformed

    private void loan_calculateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loan_calculateActionPerformed
        double interest = Double.parseDouble(ir.getText());
        int year = Integer.parseInt(ny.getText());
        double loanAmount = Double.parseDouble(la.getText());
        double monthlyInterestRate = interest / 1200;
        double monthlyPayment = loanAmount * monthlyInterestRate / (1 -(1 / Math.pow(1 + monthlyInterestRate, year * 12)));
        double totalPayment = monthlyPayment * year * 12;
        mp.setText(String.format("$%.2f", monthlyPayment));
        tp.setText(String.format("$%.2f", totalPayment));
    }//GEN-LAST:event_loan_calculateActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton expense_delete;
    private javax.swing.JTextField ir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField la;
    private javax.swing.JButton loan_calculate;
    private javax.swing.JTextField mp;
    private javax.swing.JTextField ny;
    private javax.swing.JTextField savings_amount;
    private javax.swing.JButton savings_create;
    private javax.swing.JTextField savings_date;
    private javax.swing.JTextField savings_description;
    private javax.swing.JButton savings_search;
    private javax.swing.JButton savings_update;
    private javax.swing.JComboBox<String> search_savings;
    private javax.swing.JTextField tp;
    // End of variables declaration//GEN-END:variables
}
